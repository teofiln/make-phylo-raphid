# ! /bin/bash

echo "Installing BMS package in R"


R CMD INSTALL -l Rlib dependencies/BMS_0.3.3.tar.gz
